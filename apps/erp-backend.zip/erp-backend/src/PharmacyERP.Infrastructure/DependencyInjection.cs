using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using PharmacyERP.Application.Common.Interfaces.Context;
using PharmacyERP.Application.Common.Interfaces.Persistence;
using PharmacyERP.Application.Features.Identity.Interfaces;
using PharmacyERP.Application.Features.Catalog.Interfaces;
using PharmacyERP.Application.Features.Integration.Interfaces;
using PharmacyERP.Infrastructure.Persistence.Database;
using PharmacyERP.Infrastructure.Persistence.Interceptors;
using PharmacyERP.Infrastructure.Persistence.Repositories;
using PharmacyERP.Infrastructure.Persistence.Repositories.Catalog;
using PharmacyERP.Infrastructure.Persistence.Repositories.Integration;
using PharmacyERP.Infrastructure.Persistence.Repositories.Identity;
using PharmacyERP.Infrastructure.Auth;
using PharmacyERP.Infrastructure.Persistence.UoW;
using PharmacyERP.Infrastructure.Services.Context;
using PharmacyERP.Application.Common.Interfaces.CrossModule;
using PharmacyERP.Application.Features.Inventory.Interfaces;
using PharmacyERP.Infrastructure.Persistence.Repositories.Inventory;

namespace PharmacyERP.Infrastructure;

public static class DependencyInjection
{
    public static IServiceCollection AddInfrastructureServices(this IServiceCollection services, IConfiguration configuration)
    {
        services.AddHttpContextAccessor();

        services.AddScoped<ITenantContext, TenantContext>();
        services.AddScoped<ICurrentUser, CurrentUser>();
        services.AddSingleton<IDateTimeProvider, DateTimeProvider>();
        services.AddSingleton<IRuntimeModeProvider, RuntimeModeProvider>();

        services.AddScoped<TenantRlsConnectionInterceptor>();

        var connectionString = configuration.GetConnectionString("DefaultConnection")
            ?? "Host=localhost;Database=pharmacy_erp;Username=postgres;Password=postgres";

        services.AddDbContext<PharmacyDbContext>((sp, options) =>
        {
            var rlsInterceptor = sp.GetRequiredService<TenantRlsConnectionInterceptor>();
            options.UseNpgsql(connectionString)
                   .AddInterceptors(rlsInterceptor);
        });

        services.AddScoped<IUnitOfWork, UnitOfWork>();
        services.AddScoped(typeof(IGenericRepository<>), typeof(GenericRepository<>));

        services.AddScoped<IIdempotencyRepository, IdempotencyRepository>();
        services.AddScoped<IOutboxRepository, OutboxRepository>();
        services.AddScoped<IAuditLogRepository, AuditLogRepository>();

        services.AddScoped<IOrganizationRepository, OrganizationRepository>();
        services.AddScoped<IBranchRepository, BranchRepository>();
        services.AddScoped<IEmployeeRepository, EmployeeRepository>();
        services.AddScoped<IUserAccountRepository, UserAccountRepository>();
        services.AddScoped<IBranchEnrollmentRepository, BranchEnrollmentRepository>();
        services.AddScoped<IUserRefreshTokenRepository, UserRefreshTokenRepository>();
        services.AddSingleton<JwksKeyProvider>();
        services.AddScoped<Microsoft.AspNetCore.Identity.PasswordHasher<PharmacyERP.Domain.Entities.Identity.UserAccount>>();
        services.AddScoped<IPasswordHasherService, PasswordHasherService>();
        services.AddScoped<IJwtTokenGenerator, JwtTokenGenerator>();
        services.AddScoped<TenantUserStore>();
        // Repositories Registration
        services.AddScoped<IInventoryLocationRepository, InventoryLocationRepository>();
        services.AddScoped<IInventoryBatchRepository, InventoryBatchRepository>();
        services.AddScoped<IStockBalanceRepository, StockBalanceRepository>();
        services.AddScoped<IInventoryTxnRepository, InventoryTxnRepository>();

        // Cross-Module Services Registration
        services.AddScoped<IBranchDefaultLocationSeeder, BranchDefaultLocationSeeder>();
        services.AddScoped<INonLotBatchInitializer2, NonLotBatchInitializer>();
        services.AddScoped<IProductInventoryUsageChecker2, ProductInventoryUsageChecker>();

        return services;
    }
}
